from manta.cli import main

main()
