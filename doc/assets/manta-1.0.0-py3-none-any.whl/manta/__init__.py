from manta.manta import Manta
from manta.cli import main

if __name__ == "__main__":
    main()
